import React, { useState, useRef } from 'react';
import { SimulationParams, ViewMode } from '../types';
import { toneEngine } from '../utils/toneEngine';
import { youtubeExporter } from '../utils/recorder';
import { Video, StopCircle, Clapperboard } from 'lucide-react';

interface Props {
    params: SimulationParams;
    setParams: React.Dispatch<React.SetStateAction<SimulationParams>>;
    setMode: (m: ViewMode) => void;
    isPlayingAudio: boolean;
}

export const DirectorController: React.FC<Props> = ({ params, setParams, setMode, isPlayingAudio }) => {
    const [isDirecting, setIsDirecting] = useState(false);
    const [timeElapsed, setTimeElapsed] = useState(0);
    const requestRef = useRef<number>();
    const startTimeRef = useRef<number>(0);
    const hasFracturedRef = useRef<boolean>(false);
    const isRecordingRef = useRef<boolean>(false);

    const startSequence = async () => {
        setIsDirecting(true);
        isRecordingRef.current = true;
        setMode(ViewMode.SANDBOX);
        hasFracturedRef.current = false;
        
        // Reset Params for Start
        setParams(prev => ({
            ...prev,
            distortion: 0.1,
            fracture: false,
            interferenceA: Math.sqrt(42),
            interferenceB: Math.sqrt(51) // Step 1
        }));

        // Ensure audio is ready
        await toneEngine.init();
        toneEngine.start();
        
        // Start Recording
        const canvas = document.querySelector('canvas');
        if (canvas) {
            youtubeExporter.start(canvas);
        }

        startTimeRef.current = performance.now();
        requestRef.current = requestAnimationFrame(animate);
    };

    const stopSequence = async () => {
        setIsDirecting(false);
        isRecordingRef.current = false;
        if (requestRef.current) cancelAnimationFrame(requestRef.current);
        toneEngine.stop();
        await youtubeExporter.stop(`Root42_PhaseII_TheBreach`);
    };

    const animate = (time: number) => {
        let elapsed = 0;
        
        if (isRecordingRef.current) {
            // Fixed timestep logic: Advance time by exactly 1/60s per frame
            elapsed = timeElapsed + (1/60);
        } else {
            // Wall clock logic
            elapsed = (time - startTimeRef.current) / 1000;
        }
        
        setTimeElapsed(elapsed);

        // --- TIMELINE LOGIC ---
        
        // 0-30s: The Gaze (Slow Build)
        if (elapsed < 30) {
            // Linear distortion ramp 0.1 -> 0.3
            const d = 0.1 + (elapsed / 30) * 0.2;
            
            // Update State
            setParams(prev => ({ ...prev, distortion: d }));
            
            toneEngine.setDistortion(d * 0.5);
            toneEngine.setFilter(200 + (elapsed/30)*1000); // Open filter slowly
        }
        // 30-50s: The Twitch (High Stress)
        else if (elapsed < 50) {
            // Jittery distortion
            const progress = (elapsed - 30) / 20;
            const jitter = Math.random() * 0.1 * progress;
            const d = 0.3 + progress * 0.4 + jitter;
            
            setParams(prev => ({ ...prev, distortion: d }));
            toneEngine.setDistortion(d);
            toneEngine.setFilter(1200 + progress * 2000);
        }
        // 50s: THE BREACH (Drop)
        else if (elapsed >= 50 && !hasFracturedRef.current) {
             // Trigger once
             hasFracturedRef.current = true;
             setParams(prev => ({ ...prev, fracture: true, distortion: 1.0 }));
             toneEngine.triggerDrop();
        }
        // 50s+: Post-Breach Stabilization
        else if (elapsed > 50) {
             // Keep fracture, slowly reduce distortion to stable high
             const decay = Math.max(0.5, 1.0 - (elapsed - 50) * 0.05);
             setParams(prev => ({ ...prev, distortion: decay, fracture: true }));
        }

        if (elapsed < 65) {
            requestRef.current = requestAnimationFrame(animate);
        } else {
            stopSequence();
        }
    };

    return (
        <div className="mt-4 border-t border-gray-800 pt-4">
             <div className="flex items-center gap-2 text-xs font-mono text-yellow-400 mb-2">
                <Clapperboard size={14} /> DIRECTOR MODE
            </div>
            {!isDirecting ? (
                <button 
                    onClick={startSequence}
                    className="w-full py-2 bg-yellow-900/30 border border-yellow-600 text-yellow-500 rounded font-mono text-xs hover:bg-yellow-900/50 transition flex items-center justify-center gap-2"
                >
                    <Video size={14} /> INITIATE 'THE BREACH' SEQUENCE
                </button>
            ) : (
                <div className="space-y-2">
                    <div className="w-full bg-gray-800 h-1 rounded overflow-hidden">
                        <div 
                            className="bg-yellow-500 h-full transition-all duration-100 ease-linear" 
                            style={{ width: `${(timeElapsed / 60) * 100}%` }}
                        />
                    </div>
                    <div className="flex justify-between text-[10px] font-mono text-yellow-500">
                        <span>T+{timeElapsed.toFixed(1)}s</span>
                        <span>{timeElapsed < 30 ? 'PHASE 1: GAZE' : timeElapsed < 50 ? 'PHASE 2: STRESS' : 'PHASE 3: BREACH'}</span>
                    </div>
                    <button 
                        onClick={stopSequence}
                        className="w-full py-2 bg-red-900/30 border border-red-600 text-red-500 rounded font-mono text-xs hover:bg-red-900/50 transition flex items-center justify-center gap-2"
                    >
                        <StopCircle size={14} /> ABORT SEQUENCE
                    </button>
                </div>
            )}
        </div>
    );
};
