import express from "express";
import { createServer as createViteServer } from "vite";
import * as h3 from "h3-js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Naming Engine Logic
  const VOICES = {
    "Silence": "0", "Density": "p", "Fracture": "s",
    "Gesture": "l", "Heartbeat": "m", "Warning": "z", "Chorus": "a"
  };

  app.post("/api/name", (req, res) => {
    const { lat, lng, focus } = req.body;
    if (lat === undefined || lng === undefined) {
      return res.status(400).json({ error: "Missing lat/lng" });
    }

    const h3Index = h3.latLngToCell(lat, lng, 9);
    
    // Phonetic Naming Protocol
    const rawBits = BigInt("0x" + h3Index);
    
    const generateName = (index: string) => {
      const bits = BigInt("0x" + index);
      let name = "";
      const voiceValues = Object.values(VOICES);
      for (let i = 0; i < 7; i++) {
        const voiceKey = Number((bits >> BigInt(i * 3)) & 0x7n);
        name += voiceValues[voiceKey % 7];
      }
      return `Node_${name.charAt(0).toUpperCase() + name.slice(1)}`;
    };

    const name = generateName(h3Index);

    // Perception Loop: Scan Neighbors (k-ring of 1)
    const neighbors = h3.gridDisk(h3Index, 1);
    const perceptionMap = neighbors.map(neighbor => {
      const isResonant = (BigInt("0x" + neighbor) ^ 17n) % 2n === 0n;
      return {
        address: neighbor,
        name: generateName(neighbor),
        state: isResonant ? "Resonant" : "Fractured"
      };
    });

    // 7th Ripple Lens Focus
    const isObserverBitSet = (rawBits >> 7n) & 1n;
    const focusFactor = focus ? (1.0 / (focus * 17)) : 1.0;

    res.json({
      h3Index,
      name,
      perceptionMap,
      focus: {
        active: isObserverBitSet === 1n,
        factor: focusFactor
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
    app.get("*", (req, res) => {
      res.sendFile("dist/index.html", { root: "." });
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
