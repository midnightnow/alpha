import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { PMG_CONSTANTS } from '../constants';

const vertexShader = `
  varying vec2 vUv;
  varying float vDist;
  void main() {
    vUv = uv;
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    vDist = length(position.xy);
    gl_Position = projectionMatrix * mvPosition;
  }
`;

const fragmentShader = `
  uniform float uTime;
  uniform float uResonance;
  uniform float uHadesGap;
  uniform float uShearAngle;
  uniform float uFocus;
  varying vec2 vUv;
  varying float vDist;

  void main() {
    // Parabolic Lens Focus (7th Ripple)
    vec2 centeredUv = vUv - 0.5;
    float lensFactor = 1.0 + uFocus * dot(centeredUv, centeredUv);
    vec2 distortedUv = centeredUv * lensFactor + 0.5;
    
    float dist = length(distortedUv - 0.5) * 100.0;
    float mirror = sqrt(42.0) / uHadesGap;
    
    // The 5-6-7 Stack Interference
    float w5 = sin(dist * 5.0 - uTime * 2.0);
    float w6 = sin(dist * 6.0 - uTime * 2.0);
    float w7 = sin(dist * 7.0 - uTime * 2.0);
    
    // Virtual Mirror Reflection
    float reflection = sin((mirror - dist) * uResonance);
    
    // The Nodal Sum (The Standing Man)
    float nodes = (w5 + w6 + w7) * reflection;
    
    // Snap to Shear Angle at Root 42
    float angle = atan(centeredUv.y, centeredUv.x);
    float shearFactor = cos(angle - radians(uShearAngle));
    
    // Vision Cone (7th Chakra)
    float cone = smoothstep(0.5, 0.0, length(centeredUv));
    
    float threshold = step(0.98, nodes * shearFactor * cone);
    
    // Vitrification (Sintering) effect
    vec3 color = vec3(threshold);
    float alpha = threshold > 0.1 ? 1.0 : 0.05;
    
    // 7th Ripple Microcosm (Lens Glow)
    vec3 glow = vec3(0.0, 1.0, 0.8) * uFocus * 0.5;
    
    gl_FragColor = vec4(color * vec3(0.0, 0.7, 1.0) + glow, alpha);
  }
`;

export const GenesisVisualizer: React.FC<{ resonance: number; focus: number }> = ({ resonance, focus }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const materialRef = useRef<THREE.ShaderMaterial | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(75, containerRef.current.clientWidth / containerRef.current.clientHeight, 0.1, 1000);
    camera.position.z = 50;
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const geometry = new THREE.PlaneGeometry(100, 100, 128, 128);
    const material = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 },
        uResonance: { value: resonance },
        uHadesGap: { value: PMG_CONSTANTS.HADES_GAP },
        uShearAngle: { value: PMG_CONSTANTS.SHEAR_ANGLE },
        uFocus: { value: focus },
      },
      vertexShader,
      fragmentShader,
      transparent: true,
      side: THREE.DoubleSide,
    });
    materialRef.current = material;

    const plane = new THREE.Mesh(geometry, material);
    scene.add(plane);

    // H3 Boundary Ring
    const ringGeometry = new THREE.RingGeometry(PMG_CONSTANTS.ROOT_42 / PMG_CONSTANTS.HADES_GAP, (PMG_CONSTANTS.ROOT_42 / PMG_CONSTANTS.HADES_GAP) + 0.5, 64);
    const ringMaterial = new THREE.MeshBasicMaterial({ color: 0x00ffcc, side: THREE.DoubleSide, transparent: true, opacity: 0.5 });
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    scene.add(ring);

    const animate = (time: number) => {
      if (materialRef.current) {
        materialRef.current.uniforms.uTime.value = time / 1000;
      }
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };

    requestAnimationFrame(animate);

    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) {
        containerRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  useEffect(() => {
    if (materialRef.current) {
      materialRef.current.uniforms.uResonance.value = resonance;
      materialRef.current.uniforms.uFocus.value = focus;
    }
  }, [resonance, focus]);

  return <div ref={containerRef} className="w-full h-full" id="canvas-container" />;
};
